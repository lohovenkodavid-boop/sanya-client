package com.sanya.client;

import net.minecraft.class_11719;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_2960;
import net.minecraft.class_5250;

/**
 * Smooth TrueType UI font (Carlito, with DejaVu Sans for symbols) instead of the pixel Minecraft font.
 * Defined in assets/sanya/font/ui.json and ui_bold.json; can be switched off in the settings.
 */
public final class UiFont {
    private UiFont() { }

    public static boolean enabled = true;

    private static final class_2583 REGULAR = class_2583.field_24360.method_27704(new class_11719.class_11721(class_2960.method_60655("sanya", "ui")));
    private static final class_2583 BOLD = class_2583.field_24360.method_27704(new class_11719.class_11721(class_2960.method_60655("sanya", "ui_bold")));

    public static class_2561 regular(String s) {
        class_5250 t = class_2561.method_43470(s);
        return enabled ? t.method_10862(REGULAR) : t;
    }

    public static class_2561 bold(String s) {
        class_5250 t = class_2561.method_43470(s);
        return enabled ? t.method_10862(BOLD) : t.method_27692(net.minecraft.class_124.field_1067);
    }
}
