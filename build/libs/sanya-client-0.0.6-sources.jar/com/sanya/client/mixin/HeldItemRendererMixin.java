package com.sanya.client.mixin;

import com.sanya.client.SanyaClient;
import net.minecraft.class_11659;
import net.minecraft.class_1306;
import net.minecraft.class_4587;
import net.minecraft.class_759;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_759.class)
public abstract class HeldItemRendererMixin {
    @Inject(method = "renderArm", at = @At("HEAD"))
    private void sanya$echoArmStart(class_4587 matrices, class_11659 queue, int light, class_1306 arm, CallbackInfo ci) {
        if (!SanyaClient.echoHandsEnabled) return;
        matrices.method_22903();
        float pulse = (float) Math.sin(System.nanoTime() / 260_000_000.0) * 0.012f;
        matrices.method_22904(arm == class_1306.field_6183 ? 0.008 : -0.008, pulse, 0.0);
        matrices.method_22905(1.045f + pulse, 1.045f + pulse, 1.045f + pulse);
    }

    @Inject(method = "renderArm", at = @At("TAIL"))
    private void sanya$echoArmEnd(class_4587 matrices, class_11659 queue, int light, class_1306 arm, CallbackInfo ci) {
        if (SanyaClient.echoHandsEnabled) matrices.method_22909();
    }

    @Inject(method = "renderArmHoldingItem", at = @At("HEAD"))
    private void sanya$echoHeldArmStart(class_4587 matrices, class_11659 queue, int light,
                                        float equipProgress, float swingProgress, class_1306 arm, CallbackInfo ci) {
        if (!SanyaClient.echoHandsEnabled) return;
        matrices.method_22903();
        float pulse = (float) Math.sin(System.nanoTime() / 260_000_000.0) * 0.012f;
        matrices.method_22904(arm == class_1306.field_6183 ? 0.008 : -0.008, pulse, 0.0);
        matrices.method_22905(1.045f + pulse, 1.045f + pulse, 1.045f + pulse);
    }

    @Inject(method = "renderArmHoldingItem", at = @At("TAIL"))
    private void sanya$echoHeldArmEnd(class_4587 matrices, class_11659 queue, int light,
                                      float equipProgress, float swingProgress, class_1306 arm, CallbackInfo ci) {
        if (SanyaClient.echoHandsEnabled) matrices.method_22909();
    }
}
